package code;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;

public class Run {

	public static void main(String[] args) throws IOException {

		File file = new File(System.getProperty("user.dir")	+ "\\src\\code\\xsl\\WRX.xsl");

		FileInputStream src = new FileInputStream(file);
		FileChannel srcChannel = src.getChannel();
		long flag = 0;
		String catalog = "";
		String massiv[] = new String[12];
		
		massiv[0] = "A:\\Program Files\\Microsoft Office\\Office14\\Bibliography\\Style\\WRX.xsl";
		massiv[1] = "D:\\Program Files\\Microsoft Office\\Office14\\Bibliography\\Style\\WRX.xsl";
		massiv[2] = "E:\\Program Files\\Microsoft Office\\Office14\\Bibliography\\Style\\WRX.xsl";
		
		massiv[3] = "C:\\Program Files (x86)\\Microsoft Office\\Office14\\Bibliography\\Style\\WRX.xsl";
		massiv[4] = "D:\\Program Files (x86)\\Microsoft Office\\Office14\\Bibliography\\Style\\WRX.xsl";
		massiv[5] = "E:\\Program Files (x86)\\Microsoft Office\\Office14\\Bibliography\\Style\\WRX.xsl";
		
		massiv[6] = "C:\\Program Files\\Microsoft Office\\Office12\\Bibliography\\Style\\WRX.xsl";
		massiv[7] = "D:\\Program Files\\Microsoft Office\\Office12\\Bibliography\\Style\\WRX.xsl";
		massiv[8] = "E:\\Program Files\\Microsoft Office\\Office12\\Bibliography\\Style\\WRX.xsl";
		
		massiv[9] = "C:\\Program Files (x86)\\Microsoft Office\\Office12\\Bibliography\\Style\\WRX.xsl";
		massiv[10] = "D:\\Program Files (x86)\\Microsoft Office\\Office12\\Bibliography\\Style\\WRX.xsl";
		massiv[11] = "E:\\Program Files (x86)\\Microsoft Office\\Office12\\Bibliography\\Style\\WRX.xsl";
		
		Search sFile = new Search();
		for (String value : massiv) {
			if (flag == 0) {
				catalog = value;
				flag = sFile.search(srcChannel, catalog);
			} else break;
		}


		if (flag == 0){
			code.gui.MainForm form = new code.gui.MainForm(srcChannel); 
			form.setVisible(true);
		} else 
			System.out.println("GooD!");
	}

}

